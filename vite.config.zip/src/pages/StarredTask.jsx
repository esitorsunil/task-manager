
const StarredTask = () => {
  return (
    <div>
      <h2>Starred Tasks</h2>
      <p>Here you can manage your starred tasks.</p>
    </div>
  )
}

export default StarredTask
