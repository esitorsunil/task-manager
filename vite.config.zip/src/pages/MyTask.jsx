
const MyTask = () => {
  return (
    <div>
      <h2>My Tasks</h2>
      <p>Here you can manage your tasks.</p>
    </div>
  )
}

export default MyTask
