import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const dummyCollaborators = [
  { id: 1, username: 'collab1', password: 'pass1' },
  { id: 2, username: 'collab2', password: 'pass2' },
  { id: 3, username: 'collab3', password: 'pass3' },
  { id: 4, username: 'collab4', password: 'pass4' },
  { id: 5, username: 'collab5', password: 'pass5' },
  { id: 6, username: 'collab6', password: 'pass6' },
  { id: 7, username: 'collab7', password: 'pass7' },
  { id: 8, username: 'collab8', password: 'pass8' },
  { id: 9, username: 'collab9', password: 'pass9' },
  { id: 10, username: 'collab10', password: 'pass10' },
];

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    const user = dummyCollaborators.find(
      (u) => u.username === username && u.password === password
    );
    if (user) {
      localStorage.setItem('collabUser', JSON.stringify(user));
      navigate('/dashboard');
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <div>
      <h2>Collaborator Login</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;