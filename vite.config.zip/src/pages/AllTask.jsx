
const AllTask = () => {
  return (
    <div>
      <h2>All Tasks</h2>
      <p>Here you can manage all your tasks.</p>
    </div>
  )
}

export default AllTask
