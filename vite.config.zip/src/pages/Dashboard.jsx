import React from 'react';

const dummyEmployees = [
  { id: 1, name: 'Alice Johnson', role: 'Engineer' },
  { id: 2, name: 'Bob Smith', role: 'Designer' },
  { id: 3, name: 'Charlie Brown', role: 'Product Manager' },
  { id: 4, name: 'David Williams', role: 'Developer' },
  { id: 5, name: 'Ella Davis', role: 'QA Analyst' },
  { id: 6, name: 'Frank Miller', role: 'HR' },
  { id: 7, name: 'Grace Lee', role: 'Engineer' },
  { id: 8, name: 'Henry Wilson', role: 'Support' },
  { id: 9, name: 'Isla Moore', role: 'Marketing' },
  { id: 10, name: 'Jack Taylor', role: 'Finance' },
];

const Dashboard = () => {
  const user = JSON.parse(localStorage.getItem('collabUser'));

  return (
    <div>
      <h2>Welcome, {user.username}</h2>
      <h3>Employee List</h3>
      <ul>
        {dummyEmployees.map((emp) => (
          <li key={emp.id}>{emp.name} - {emp.role}</li>
        ))}
      </ul>
    </div>
  );
};

export default Dashboard;
